extends CharacterBody2D

const SPEED = 300.0

@onready var anim =get_node("AnimatedSprite2D")
	
func _physics_process(delta: float) -> void:
	var input_vector = Vector2(
		Input.get_axis("ui_left", "ui_right"),
		Input.get_axis("ui_up", "ui_down")
	)

	if input_vector != Vector2.ZERO:
		input_vector = input_vector.normalized()
		velocity = input_vector * SPEED
	else:
		velocity = Vector2.ZERO

	move_and_slide()
